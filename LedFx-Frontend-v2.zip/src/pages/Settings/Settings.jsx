import { useEffect, useState } from 'react';
import useStore from '../../utils/apiStore';
import { Accordion, AccordionSummary, Typography, AccordionDetails } from '@material-ui/core';
import { ExpandMore } from '@material-ui/icons';
import AudioCard from './AudioCard';
import WledCard from './WledCard';
import Webaudio from './Webaudio';
import ClientAudioCard from './ClientAudioCard';
import { useStyles } from './SettingsComponents'
import UICard from './UICard';
import GeneralCard from './GeneralCard';
import { useLocation } from 'react-router-dom';

const Settings = () => {

  const classes = useStyles();
  const features = useStore((state) => state.features);
  const settingsExpanded = useStore((state) => state.settingsExpanded);
  const setSettingsExpanded = useStore((state) => state.setSettingsExpanded);
  const loc = useLocation()

  const handleExpanded = (panel, event, isExpanded) => {
    setSettingsExpanded(isExpanded ? panel : false);
  };

  useEffect(()=>{
    if (loc.search.indexOf("ui") > -1 ) {
      setSettingsExpanded('panel2')
    }
  },[loc])

  return (
    <>
      <div className={classes.card}>
        <Accordion expanded={settingsExpanded === 'all' || settingsExpanded === 'panel3'} onChange={(event, isExpanded)=>handleExpanded('panel3', event, isExpanded)}>
          <AccordionSummary
            expandIcon={<ExpandMore />}
            aria-controls="panel3a-content"
            id="panel3a-header"
          >
            <Typography>General</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <GeneralCard />
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={settingsExpanded === 'all' || settingsExpanded === 'panel1'} onChange={(event, isExpanded)=>handleExpanded('panel1', event, isExpanded)}>
          <AccordionSummary
            expandIcon={<ExpandMore />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>Audio Settings</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <div>
              {features['webaudio'] &&
                <Webaudio style={{ position: 'absolute', right: '3.5rem', top: '0.3rem' }} />
              }
              <ClientAudioCard />
              <AudioCard className={`${classes.audioCard} step-settings-one`} />
            </div>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={settingsExpanded === 'all' || settingsExpanded === 'panel2'} onChange={(event, isExpanded)=>handleExpanded('panel2', event, isExpanded)}>
          <AccordionSummary
            expandIcon={<ExpandMore />}
            aria-controls="panel2a-content"
            id="panel2a-header"
          >
            <Typography>UI Settings</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <UICard />
          </AccordionDetails>
        </Accordion>

        {features['wled'] &&
          <Accordion expanded={settingsExpanded === 'all' || settingsExpanded === 'panel4'} onChange={(event, isExpanded)=>handleExpanded('panel4', event, isExpanded)}>
            <AccordionSummary
              expandIcon={<ExpandMore />}
              aria-controls="panel4a-content"
              id="panel4a-header"
            >
              <Typography>WLED Settings</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <div>
                <WledCard className={`${classes.card} step-settings-five`} />
              </div>
            </AccordionDetails>
          </Accordion>}
      </div>
    </>
  );
};

export default Settings;
