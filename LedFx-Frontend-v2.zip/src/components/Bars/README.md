[![creator](https://img.shields.io/badge/CREATOR-Yeon-blue.svg?logo=github&logoColor=white)](https://github.com/YeonV) [![creator](https://img.shields.io/badge/A.K.A-Blade-darkred.svg?logo=github&logoColor=white)](https://github.com/YeonV)

---

![logo192](https://user-images.githubusercontent.com/28861537/119760144-c5126680-bea9-11eb-991a-c08eedbc5929.png)


---

# Bars

We are using material-ui for different kind of bars:

LeftBar: [drawer](https://material-ui.com/components/drawers/)

TopBar: [app-bar](https://material-ui.com/components/app-bar/)

BottomBar: [bottom-navigation](https://material-ui.com/components/bottom-navigation/)

MessageBar: [snackbar](https://material-ui.com/components/snackbars/)