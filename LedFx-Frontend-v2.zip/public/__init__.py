"""ledfx_frontend"""
import os


def where():
    return os.path.dirname(__file__)
